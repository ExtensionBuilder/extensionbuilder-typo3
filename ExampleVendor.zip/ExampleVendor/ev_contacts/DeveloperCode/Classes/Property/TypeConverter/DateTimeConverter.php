<?php

declare(strict_types = 1);

namespace ExampleVendor\EvContacts\Property\TypeConverter;

use TYPO3\CMS\Extbase\Property\TypeConverter\AbstractTypeConverter;

use TYPO3\CMS\Extbase\Error\Error;
use TYPO3\CMS\Extbase\Property\Exception\InvalidPropertyMappingConfigurationException;
use TYPO3\CMS\Extbase\Property\Exception\TypeConverterException;
use TYPO3\CMS\Extbase\Property\PropertyMappingConfigurationInterface;
use TYPO3\CMS\Extbase\Utility\LocalizationUtility;

class DateTimeConverter extends AbstractTypeConverter
{

    public const CONFIGURATION_DATE_FORMAT = 'dateFormat';
    public const DEFAULT_DATE_FORMAT = \DateTimeInterface::W3C;

    /**
     * Converts $source to a \DateTime using the configured dateFormat
     *
     * @param string|int|array $source the string to be converted to a \DateTime object
     * @param string $targetType must be "DateTime"
     * @param array $convertedChildProperties not used currently
     * @throws TypeConverterException
     * @internal only to be used within Extbase, not part of TYPO3 Core API.
     */
    public function convertFrom(
        $source,
        string $targetType,
        array $convertedChildProperties = [],
        ?PropertyMappingConfigurationInterface $configuration = null,
    ): null|\DateTime|Error {
        $dateFormat = $this->getDefaultDateFormat($configuration);
        if (is_string($source)) {
            $dateAsString = $source;
        } elseif (is_int($source)) {
            $dateAsString = (string)$source;
        } else {
            if (isset($source['date']) && is_string($source['date'])) {
                $dateAsString = $source['date'];
            } elseif (isset($source['date']) && is_int($source['date'])) {
                $dateAsString = (string)$source['date'];
            } elseif ($this->isDatePartKeysProvided($source)) {
                if ($source['day'] < 1 || $source['month'] < 1 || $source['year'] < 1) {
                    return new Error(
                        'Could not convert the given date parts into a DateTime object because one or more parts were 0.',
                         1333032779,
                    );
                }
                $dateAsString = sprintf('%d-%d-%d', $source['year'], $source['month'], $source['day']);
            } else {
                throw new TypeConverterException(
                    'Could not convert the given source into a DateTime object because it was not an array with a valid date as a string',
                    1308003914,
                );
            }
            if (isset($source['dateFormat']) && $source['dateFormat'] !== '') {
                $dateFormat = $source['dateFormat'];
            }
        }
        if ($dateAsString === '') {
            return null;
        }
        if (ctype_digit($dateAsString) && $configuration === null && (!is_array($source) || !isset($source['dateFormat']))) {
            // todo: type converters are never called without a property mapping configuration
            $dateFormat = 'U';
        }
        if (is_array($source) && isset($source['timezone']) && (string)$source['timezone'] !== '') {
            try {
                $timezone = new \DateTimeZone($source['timezone']);
            } catch (\Exception $e) {
                throw new TypeConverterException(
                    'The specified timezone "' . $source['timezone'] . '" is invalid.',
                    1308240974,
                );
            }
            $date = $targetType::createFromFormat($dateFormat, $dateAsString, $timezone);
        } else {
            $date = $targetType::createFromFormat($dateFormat, $dateAsString);
        }

        if ($date === false) {
            $date = $targetType::createFromFormat(str_replace(['\\', ':', 'TH', 'H', 'i', 's', 'P'], '', $dateFormat), $dateAsString);
		}

        if ($date === false) {
            $date = $targetType::createFromFormat(str_replace(['\\', ':', 'TH', 'H', 'i', 's', 'P'], '', $dateFormat), $dateAsString);
		}
        if ($date === false) {
            return new \TYPO3\CMS\Extbase\Validation\Error(
                $this->translateErrorMessage(
                    'LLL:EXT:extbase/Resources/Private/Language/locallang.xlf:converter.datetime.notrecognized',
                ),
                1307719788,
                [$dateAsString, $dateFormat],
            );
        }
        if (is_array($source)) {
            $date = $this->overrideTimeIfSpecified($date, $source);
        }
        return $date;
    }

    /**
     * Wrap static call to LocalizationUtility to simplify unit testing.
     */
    protected function translateErrorMessage(
        string $translateKey,
    ): string {
        return LocalizationUtility::translate($translateKey) ?? '';
    }

    /**
     * Returns whether date information (day, month, year) are present as keys in $source.
     */
    protected function isDatePartKeysProvided(
        array $source,
    ): bool {
        return isset($source['day'], $source['month'], $source['year']) &&
            ctype_digit($source['day']) && ctype_digit($source['month']) && ctype_digit($source['year']);
    }

    /**
     * Determines the default date format to use for the conversion.
     * If no format is specified in the mapping configuration DEFAULT_DATE_FORMAT is used.
     *
     * @throws InvalidPropertyMappingConfigurationException
     */
    protected function getDefaultDateFormat(
        ?PropertyMappingConfigurationInterface $configuration = null,
    ): string {
        if ($configuration === null) {
            // todo: type converters are never called without a property mapping configuration
            return self::DEFAULT_DATE_FORMAT;
        }
        $dateFormat = $configuration->getConfigurationValue(DateTimeConverter::class, self::CONFIGURATION_DATE_FORMAT);
        if ($dateFormat === null) {
            return self::DEFAULT_DATE_FORMAT;
        }
        if (!is_string($dateFormat)) {
            throw new InvalidPropertyMappingConfigurationException(
                'CONFIGURATION_DATE_FORMAT must be of type string, "' . get_debug_type($dateFormat) . '" given',
                1307719569,
            );
        }
        return $dateFormat;
    }

    /**
     * Overrides hour, minute & second of the given date with the values in the $source array
     */
    protected function overrideTimeIfSpecified(
        \DateTime $date,
        array $source,
    ): \DateTime {
        if (!isset($source['hour']) && !isset($source['minute']) && !isset($source['second'])) {
            return $date;
        }
        $hour = isset($source['hour']) ? (int)$source['hour'] : 0;
        $minute = isset($source['minute']) ? (int)$source['minute'] : 0;
        $second = isset($source['second']) ? (int)$source['second'] : 0;
        return $date->setTime($hour, $minute, $second);
    }

}